Study Atlas Free Update Mode patch

Copy these files over the matching paths in your existing GitHub project on the `study` branch.
Do NOT merge into your production branch unless you intentionally want a production deploy.
Read FREE_UPDATE_MODE.md after applying.
